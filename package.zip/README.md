# stellar-drive

Stellar drive is a cloud storage it uses AWS S3 bucket to store the files and Cognito service to secure the access.
ee
